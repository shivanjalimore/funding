package com.app.Entity;

public enum Role {
	ROLE_ADMIN,
    ROLE_ORGANIZATION,
    ROLE_CUSTOMER
}
