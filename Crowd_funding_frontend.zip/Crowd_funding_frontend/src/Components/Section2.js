import React from 'react';
import './Section2.css'; // Import custom CSS file

function Section2() {
  return (
    <div>
    <div className="container" style={{border:"3px solid blue"}}>
      <img src="./assests/baner5.jpeg" alt="Sign Up" className="center-image" />
    </div>
    <div className="container" style={{border:"3px solid blue"}}>
    <img src="./assests/baner6.jpeg" alt="Sign Up" className="center-image" />
  </div>
  </div>
  );
}

export default Section2;
