import React from "react";
import "./ExploreProjects.css"; // custom styling

function ExploreProjects() {
  return (
    <div className="explore-section text-center py-5 px-3">
      <h2 className="explore-title mb-3">Explore Our Projects</h2>
      <p className="explore-subtitle">
        Discover projects just for you and get great recommendations <br />
        when you select your interests.
      </p>
    </div>
  );
}

export default ExploreProjects;
