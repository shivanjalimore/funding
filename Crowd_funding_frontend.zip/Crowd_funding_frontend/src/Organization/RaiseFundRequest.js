import React, { useState } from "react";
import { Form, Button, Card, Container } from "react-bootstrap";
import "./RaiseFundRequest.css"; // Optional: For custom styles
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Organization from "./Organization";

function RaiseFundRequest() {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    maxAmount: "",
    endDate: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Make API call here
    console.log("Submitted data:", formData);
    toast.success("Fund request raised successfully!");
  };

  return (
    <Organization>

      <ToastContainer />
      <Card className="p-4 shadow-lg fund-card">
        <h3 className="text-center text-success mb-4">Raise Fund Request</h3>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="title" className="mb-3">
            <Form.Label className="text-success">Title</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter project title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <Form.Group controlId="description" className="mb-3">
            <Form.Label className="text-success">Description</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              placeholder="Enter project description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <Form.Group controlId="maxAmount" className="mb-3">
            <Form.Label className="text-success">Maximum Amount</Form.Label>
            <Form.Control
              type="number"
              placeholder="Enter maximum amount"
              name="maxAmount"
              value={formData.maxAmount}
              onChange={handleChange}
              required
              min={1}
            />
          </Form.Group>

          <Form.Group controlId="endDate" className="mb-4">
            <Form.Label className="text-success">End Date</Form.Label>
            <Form.Control
              type="date"
              name="endDate"
              value={formData.endDate}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <div className="text-center">
            <Button variant="success" type="submit" className="px-4">
              Submit Request
            </Button>
          </div>
        </Form>
      </Card>

    </Organization>
  );
}

export default RaiseFundRequest;
