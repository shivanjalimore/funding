import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./MyFundRequests.css";
import Organization from "./Organization";

function MyFundRequests() {
  const [funds, setFunds] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchFunds = async () => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("jwtToken")}`,
          },
        };

        const orgId = sessionStorage.getItem("organizationId");
        const response = await axios.get(
          `http://localhost:8080/admin/getFundsByOrganization/${orgId}`,
          config
        );
        setFunds(response.data);
      } catch (error) {
        console.error("Error fetching fund requests:", error);
      }
    };

    fetchFunds();
  }, []);

  const handleEdit = (fundId) => {
    navigate(`/editfund/${fundId}`);
  };

  return (
    <Organization>
      <div className="container my-4">
        <h2 className="text-success text-center mb-4">My Fund Requests</h2>
        <div className="row justify-content-center">
          {funds.length > 0 ? (
            funds.map((fund) => (
              <div className="col-md-6 mb-4" key={fund.id}>
                <div className="card border-success shadow fund-card">
                  <div className="card-body">
                    <h4 className="card-title text-success">{fund.title}</h4>
                    <p className="card-text">{fund.description}</p>
                    <ul className="list-group list-group-flush">
                      <li className="list-group-item">
                        <strong>Max Amount:</strong> ₹{fund.maxAmount}
                      </li>
                      <li className="list-group-item">
                        <strong>Raised Amount:</strong> ₹{fund.raisedAmount}
                      </li>
                      <li className="list-group-item">
                        <strong>Start Date:</strong> {fund.startDate}
                      </li>
                      <li className="list-group-item">
                        <strong>End Date:</strong> {fund.endDate}
                      </li>
                      <li className="list-group-item">
                        <strong>Status:</strong>{" "}
                        {fund.closed ? (
                          <span className="badge bg-danger">Closed</span>
                        ) : (
                          <span className="badge bg-success">Open</span>
                        )}
                      </li>
                    </ul>
                    {!fund.closed && (
                      <button
                        className="btn btn-outline-success mt-3 w-100"
                        onClick={() => handleEdit(fund.id)}
                      >
                        Edit Fund
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-muted">No fund requests found.</div>
          )}
        </div>
      </div>
    </Organization>
  );
}

export default MyFundRequests;
