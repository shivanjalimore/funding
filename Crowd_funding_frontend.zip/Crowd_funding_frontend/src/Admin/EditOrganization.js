import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Admin from "./Admin";
import "./EditOrganization.css";

function EditOrganization() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [organization, setOrganization] = useState({
    name: "",
    email: "",
    contact: "",
    pincode: "",
    address: "",
    password: ""
  });

  useEffect(() => {
    const fetchOrg = async () => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("jwtToken")}`,
          },
        };
        const res = await axios.get(`http://localhost:8080/admin/getMember/${id}`, config);
        setOrganization(res.data);
      } catch (err) {
        console.error("Failed to fetch organization:", err);
      }
    };
    fetchOrg();
  }, [id]);

  const handleChange = (e) => {
    setOrganization({ ...organization, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const config = {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("jwtToken")}`,
        },
      };
      await axios.put(`http://localhost:8080/admin/updateMember/${id}`, organization, config);
      navigate("/admin/vieworganization");
    } catch (err) {
      console.error("Error updating organization:", err);
    }
  };

  return (
    <Admin>
      <div className="edit-org-container">
        <h2>Edit Organization</h2>
        <form onSubmit={handleSubmit} className="edit-org-form">
          <label>Name</label>
          <input type="text" name="name" value={organization.name} onChange={handleChange} required />

          <label>Email</label>
          <input type="email" name="email" value={organization.email} onChange={handleChange} required />

          <label>Contact</label>
          <input type="text" name="contact" value={organization.contact} onChange={handleChange} required />

          <label>Pincode</label>
          <input type="text" name="pincode" value={organization.pincode} onChange={handleChange} required />

          <label>Address</label>
          <input type="text" name="address" value={organization.address} onChange={handleChange} required />

          <label>Password</label>
          <input type="password" name="password" value={organization.password} onChange={handleChange} required />

          <button type="submit">Update</button>
        </form>
      </div>
    </Admin>
  );
}

export default EditOrganization;
