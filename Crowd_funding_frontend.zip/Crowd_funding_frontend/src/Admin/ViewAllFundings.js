import React, { useEffect, useState } from "react";
import axios from "axios";
import Admin from "./Admin";
import "./ViewAllFundings.css";

const ViewAllFundings = () => {
  const [groupedFundings, setGroupedFundings] = useState({});

  useEffect(() => {
    const fetchFundings = async () => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("jwtToken")}`,
          },
        };

        const response = await axios.get(
          "http://localhost:8080/admin/getAllFunds",
          config
        );

        const data = response.data;

        // Grouping by organizationName
        const grouped = data.reduce((acc, fund) => {
          if (!acc[fund.organizationName]) {
            acc[fund.organizationName] = [];
          }
          acc[fund.organizationName].push(fund);
          return acc;
        }, {});

        setGroupedFundings(grouped);
      } catch (error) {
        console.error("Error fetching fundings:", error);
        alert("Failed to fetch fundings.");
      }
    };

    fetchFundings();
  }, []);

  return (
    <Admin>
      <div className="fundings-container">
        <h2>All Fundings By Organization</h2>

        {Object.keys(groupedFundings).map((orgName) => (
          <div key={orgName} className="organization-section">
            <h3 className="organization-title">{orgName}</h3>
            <div className="funds-grid">
              {groupedFundings[orgName].map((fund) => (
                <div key={fund.id} className="fund-card">
                  <h4>{fund.title}</h4>
                  <p><strong>Description:</strong> {fund.description}</p>
                  <p><strong>Max Amount:</strong> ₹{fund.maxAmount}</p>
                  <p><strong>Raised Amount:</strong> ₹{fund.raisedAmount}</p>
                  <p><strong>Duration:</strong> {fund.startDate} to {fund.endDate}</p>
                  <p><strong>Status:</strong> {fund.closed ? "Closed" : "Active"}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Admin>
  );
};

export default ViewAllFundings;
